---

kanban-plugin: basic

---

## Úkoly prioritní

- [ ] Pergola


## Úkoly krátkodobé

- [ ] Sepsat si 12 oblíbených problémů


## Rozvoj

- [ ] Zotero a citace


## Zadáno

- [ ] Odstupové vzdálenosti (e-book)
- [ ] CAD ve stavební praxi
- [ ] stawiki
- [ ] Web stavlab
- [ ] Web Michal Bělovský
- [ ] Hydroizolace spodní stavy
- [ ] RD Modrá: Podklady


## Rozpracováno



## Dokončeno



